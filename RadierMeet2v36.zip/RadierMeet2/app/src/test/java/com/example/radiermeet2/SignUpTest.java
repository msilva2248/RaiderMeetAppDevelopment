package com.example.radiermeet2;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class SignUpTest {

    @Test
    public void addition_isCorrect() {
        assertEquals(20, 10 + 10);
    }

}