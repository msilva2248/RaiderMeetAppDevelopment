package com.example.radiermeet2;

import org.junit.jupiter.api.Test;

class LoginActivityTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(10, 5 + 5);
    }

    private void assertEquals(int i, int i1) {
    }

}