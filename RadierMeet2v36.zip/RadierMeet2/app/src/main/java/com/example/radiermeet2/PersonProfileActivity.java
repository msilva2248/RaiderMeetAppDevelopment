package com.example.radiermeet2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import de.hdodenhof.circleimageview.CircleImageView;

public class PersonProfileActivity extends AppCompatActivity {

    private CircleImageView profilePicture;

    private TextView firstName, lastName, email, address, hobbies;
    private Button sendFriendRequestBtn, declineFriendRequestBtn;

    private DatabaseReference FriendRequestRef,usersRef, friendsRef;
    private FirebaseAuth mAuth;
    private String senderUserId, receiverUserId, CURRENT_STATE, saveCurrentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_profile);

        mAuth = FirebaseAuth.getInstance();
        senderUserId = mAuth.getCurrentUser().getUid();
        //get other user id
        receiverUserId = getIntent().getExtras().get("visit_user_id").toString();
        //All users
        usersRef = FirebaseDatabase.getInstance().getReference().child("Users");
        FriendRequestRef = FirebaseDatabase.getInstance().getReference().child("FriendRequests");
        friendsRef = FirebaseDatabase.getInstance().getReference().child("Friends");

        InitializeFields();

        //Extracting wanted user's information
        usersRef.child(receiverUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){

                    String otherFirstName = snapshot.child("firstName").getValue().toString();
                    String otherLastName = snapshot.child("lastName").getValue().toString();
                    //String otherEmail = snapshot.child("email").getValue().toString();
                    //String otherAddress = snapshot.child("address").getValue().toString();
                    //String otherHobbies = snapshot.child("hobbies").getValue().toString();

                    //add profile picture here

                    firstName.setText(otherFirstName);
                    lastName.setText(otherLastName);
                   // email.setText(otherEmail);
                    //address.setText(otherAddress);
                    //hobbies.setText(otherHobbies);

                    //add profile picture here

                    MaintenanceOfButtons();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        declineFriendRequestBtn.setVisibility(View.INVISIBLE);
        declineFriendRequestBtn.setEnabled(false);

        if(!senderUserId.equals(receiverUserId))
        {
            sendFriendRequestBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    sendFriendRequestBtn.setEnabled(false);

                    if(CURRENT_STATE.equals("not_friends"))
                    {
                        SendFriendRequest();
                    }
                    if(CURRENT_STATE.equals("request_sent"))
                    {
                        CancelFriendRequest();
                    }
                    if(CURRENT_STATE.equals("request_received"))
                    {
                        AcceptFriendRequest();
                    }
                    if(CURRENT_STATE.equals("friends")){
                        UnFriendAnExistingFriend();
                    }

                }
            });
        }
        else
        {
            declineFriendRequestBtn.setVisibility(View.INVISIBLE);
            sendFriendRequestBtn.setVisibility(View.INVISIBLE);
        }
    }

    private void UnFriendAnExistingFriend()
    {
        friendsRef.child(senderUserId).child(receiverUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    friendsRef.child(receiverUserId).child(senderUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                sendFriendRequestBtn.setEnabled(true);
                                CURRENT_STATE = "not_friends";
                                sendFriendRequestBtn.setText("Send Friend Request");

                                declineFriendRequestBtn.setVisibility(View.INVISIBLE);
                                declineFriendRequestBtn.setEnabled(false);
                            }
                        }
                    });
                }
            }
        });
    }

    private void AcceptFriendRequest()
    {
        Calendar calForDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("dd-MMMM-yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        //The Friends Node
        friendsRef.child(senderUserId).child(receiverUserId).child("date").setValue(saveCurrentDate).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    friendsRef.child(receiverUserId).child(senderUserId).child("date").setValue(saveCurrentDate).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                //remove record from the friend request node
                                FriendRequestRef.child(senderUserId).child(receiverUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful())
                                        {
                                            FriendRequestRef.child(receiverUserId).child(senderUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful())
                                                    {
                                                        sendFriendRequestBtn.setEnabled(true);
                                                        CURRENT_STATE = "friends";
                                                        sendFriendRequestBtn.setText("Unfriend this Person");

                                                        declineFriendRequestBtn.setVisibility(View.INVISIBLE);
                                                        declineFriendRequestBtn.setEnabled(false);
                                                    }
                                                }
                                            });
                                        }
                                    }
                                });

                            }
                        }
                    });
                }
            }
        });
    }

    private void CancelFriendRequest()
    {
        FriendRequestRef.child(senderUserId).child(receiverUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    FriendRequestRef.child(receiverUserId).child(senderUserId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                sendFriendRequestBtn.setEnabled(true);
                                CURRENT_STATE = "not_friends";
                                sendFriendRequestBtn.setText("Send Friend Request");

                                declineFriendRequestBtn.setVisibility(View.INVISIBLE);
                                declineFriendRequestBtn.setEnabled(false);
                            }
                        }
                    });
                }
            }
        });
    }

    private void MaintenanceOfButtons() {

        FriendRequestRef.child(senderUserId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.hasChild(receiverUserId))
                {
                    String request_type = snapshot.child(receiverUserId).child("request_type").getValue().toString();

                    if(request_type.equals("sent"))
                    {
                        CURRENT_STATE = "request_sent";
                        sendFriendRequestBtn.setText("Cancel Friend Request");

                        declineFriendRequestBtn.setVisibility(View.INVISIBLE);
                        declineFriendRequestBtn.setEnabled(false);
                    }
                    else if(request_type.equals("received"))
                    {
                        CURRENT_STATE = "request_received";
                        sendFriendRequestBtn.setText("Accept Friend Request");

                        declineFriendRequestBtn.setVisibility(View.VISIBLE);
                        declineFriendRequestBtn.setEnabled(true);
                        declineFriendRequestBtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                CancelFriendRequest();
                            }
                        });

                    }
                }
                else
                {
                    friendsRef.child(senderUserId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.hasChild(receiverUserId))
                            {
                                CURRENT_STATE = "friends";
                                sendFriendRequestBtn.setText("Unfriend this Person");

                                declineFriendRequestBtn.setVisibility(View.INVISIBLE);
                                declineFriendRequestBtn.setEnabled(false);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void SendFriendRequest()
    {
        FriendRequestRef.child(senderUserId).child(receiverUserId).child("request_type").setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    FriendRequestRef.child(receiverUserId).child(senderUserId).child("request_type").setValue("received").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                sendFriendRequestBtn.setEnabled(true);
                                CURRENT_STATE = "request_sent";
                                sendFriendRequestBtn.setText("Cancel Friend Request");

                                declineFriendRequestBtn.setVisibility(View.INVISIBLE);
                                declineFriendRequestBtn.setEnabled(false);
                            }
                        }
                    });
                }
            }
        });

    }

    private void InitializeFields(){

        profilePicture = (CircleImageView) findViewById(R.id.other_profile_pic);
        firstName = (TextView) findViewById(R.id.other_name);
        lastName = (TextView) findViewById(R.id.other_lastName);
        email = (TextView) findViewById(R.id.other_email);
        address = (TextView) findViewById(R.id.other_address_1);
        hobbies = (TextView) findViewById(R.id.other_hobbies);


        sendFriendRequestBtn = (Button) findViewById(R.id.send_friend_request_button);
        declineFriendRequestBtn = (Button) findViewById(R.id.decline_friend_request_button);
        CURRENT_STATE = "not_friends";
    }

}