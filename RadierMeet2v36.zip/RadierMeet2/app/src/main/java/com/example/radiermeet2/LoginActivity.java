package com.example.radiermeet2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

// import interface functions
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//import firebase
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class LoginActivity extends AppCompatActivity {
    public static final String TAG = "MyActivity";

   //button, textview, firebase auth, edittext
    private Button sign_up, sign_in;
    private TextView forgot_password, go_raiders;
    private FirebaseAuth rAuth;
    // Type new text
    private EditText user_email, user_password;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        user_email = (EditText) findViewById(R.id.et_email);
        user_password = (EditText) findViewById(R.id.et_password);

        rAuth = FirebaseAuth.getInstance();

        sign_up = (Button) findViewById(R.id.bt_signup);

        //activate to signup page
        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), SignUp.class));
            }
        });


        //Sign in parts, sign in button action
        sign_in = (Button) findViewById(R.id.bt_login);
        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user_email = LoginActivity.this.user_email.getText().toString().trim();
                final String user_password = LoginActivity.this.user_password.getText().toString().trim();

                if (user_email.isEmpty()) {
                    LoginActivity.this.user_email.setError("Please Enter Your RaiderMeet Email.");
                    LoginActivity.this.user_email.requestFocus();
                    return;
                }

                if (user_password.isEmpty()) {
                    LoginActivity.this.user_password.setError("Please Enter Your RaiderMeet Password.");
                    LoginActivity.this.user_password.requestFocus();
                    return;
                }
                // Check the email and password from the firebase authentication.
                rAuth.signInWithEmailAndPassword(user_email, user_password)
                        .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                /* If sign in fails, display a message to the user.
                                If sign in succeeds the rauth state listener will be notified and logic to handle the
                                signed in user can be handled in the listener.
                                 Toast length to long not a short, then the toast message pop up more long time.*/
                                if (!task.isSuccessful()) {
                                    Toast toast = Toast.makeText(getApplicationContext(),
                                            "Wrong Email Account or Password", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.TOP, 0, 0);
                                    toast.show();

                                } else {
                                    /*
                                    Success log in toast the message and go to the main activity page which is the home page
                                    add exception function for failing any reasons for the login in
                                     */
                                    if (task.isSuccessful()) {
                                        Toast.makeText(LoginActivity.this, "Logged In", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                    } else {
                                        Toast.makeText(LoginActivity.this, "Failed to Login" + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        });
            }
        });

        /*
        This is the text media part.
        which is showing go raiders text.
        when you click this text, the go raiders sound coming out.
        connect the graiders by using findViewById
        sound is a new directory resource file, so it has to add on raw in the resource folder.
        m4a file did not recognize on android studio, so you should convert and media file to mp3
        */
        go_raiders = (TextView) findViewById(R.id.gradiers);
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.graiders);
        go_raiders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();
            }
        });

        /*
        This part is for sending email if users forgot their password.
        Also it can check if users forgot their email account too.
        In this part it has to connect with firebase rAuth for sending an email which can change user's password.
         */
        forgot_password = (TextView) findViewById(R.id.forgot_password);
        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText reset_email = new EditText(view.getContext());
                final AlertDialog.Builder forgot_password_dialog = new AlertDialog.Builder(view.getContext());
                forgot_password_dialog.setTitle("Do You Want to Reset Password?");
                forgot_password_dialog.setMessage("Enter Your RaiderMeet Email Account.");
                forgot_password_dialog.setView(reset_email);

                /*
                This part shows the toast message to user that the reset link is going to user's email or not.
                Every function has to exception error part for preventing unexpected error.
                Open the dialog interface for sending email.
                 */
                forgot_password_dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int r) {
                        String mail = reset_email.getText().toString();
                        rAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void rVoid) {
                                Toast.makeText(LoginActivity.this, "Reset Password Link Sent To Your RaiderMeet Email.", Toast.LENGTH_LONG).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(LoginActivity.this, "Error! Please Try It Again." + e.getMessage(), Toast.LENGTH_LONG);
                            }
                        });
                    }
                });
                // Button for the click No then close the forgot password dialog interface
                forgot_password_dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int r) {

                    }
                });
                // show the forgot_password_dialog
                forgot_password_dialog.create().show();
            }
        });
    }
}
