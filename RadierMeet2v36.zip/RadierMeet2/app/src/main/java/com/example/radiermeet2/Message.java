package com.example.radiermeet2;

// Junwoo Jang


/*
    This is the first file and It's the simplest one.
    Below is Just a class that holds data.

    Instances of this class are used in ChatsActivity and in MessageActivity.

*/



// A class representing a single message
public class Message {
    public String senderUID;
    public String recipientUID;
    public String contents;
    public long timestamp;


    /*
        This function: an “empty" constructor that firebase database uses to
        make a message class from the data it has.

        Through the request to see which stored messages are in the database, it knows how to make a message object.
     */

    public Message() {
        // Used to populate Messages when using firebase
    }



    public Message(String senderUID, String recipientUID, String contents, long timestamp) {
        this.senderUID = senderUID;
        this.recipientUID = recipientUID;
        this.contents = contents;
        this.timestamp = timestamp;
    }    /*
        This constructor is for our use, to create a message objects with its fields populated.
     */

}
