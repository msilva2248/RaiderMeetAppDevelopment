package com.example.radiermeet2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class PostActivity extends AppCompatActivity {
    private EditText editTextTitle, editTextMessage;
    private DatabaseReference databaseReference;
    DrawerLayout drawerLayout;

    private StorageReference storageReference;
    FirebaseUser cUser;
    String uId;

    private static final String POSTS="Post";

    Post post;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        drawerLayout = findViewById(R.id.drawer_layout);
        databaseReference = FirebaseDatabase.getInstance().getReference(POSTS);

        // upload image references
        storageReference = FirebaseStorage.getInstance().getReference();
        cUser= FirebaseAuth.getInstance().getCurrentUser();
        uId = cUser.getUid();

        editTextTitle = (EditText) findViewById(R.id.edit_post_title);
        editTextMessage = (EditText) findViewById(R.id.edit_post_message);


        post = new Post();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1000){
            if(resultCode == Activity.RESULT_OK){
                //Save URI of chosen image
                Uri imageUri = data.getData();
                uploadImageToFirebase(imageUri);
            }
        }
    }

    public void post(View view) {
        // getting text from our edittext fields.
        String title = editTextTitle.getText().toString();
        String message = editTextMessage.getText().toString();

        if(title.isEmpty()){
            editTextTitle.setError("Please enter a title.");
            editTextTitle.requestFocus();
            return;
        }

        if(message.isEmpty()){
            editTextMessage.setError("Please enter a message.");
            editTextMessage.requestFocus();
            return;
        }

        addPostToFirebase(title, message);
        Navigation.redirectActivity(PostActivity.this, MainActivity.class);
    }

    private void uploadImageToFirebase(Uri imageUri) {
        //upload image to Firebase Storage
        final StorageReference fileRef = storageReference.child("users/" + uId +"/post.jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(PostActivity.this, "Image Uploaded.", Toast.LENGTH_SHORT).show();
                //Go back to profile page when uploading finished
//                Navigation.redirectActivity(PostActivity.this, ProfilePage.class);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(PostActivity.this, "Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addPostToFirebase(String title, String message) {
        // below 3 lines of code is used to set
        // data in our object class.
        post.setTitle(title);
        post.setMessage(message);

        // we are use add value event listener method
        // which is called with database reference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // inside the method of on Data change we are setting
                // our object class to our database reference.
                // data base reference will sends data to firebase.
//                databaseReference.setValue(post);
                databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(post);

                // after adding this data we are showing toast message.
                Toast.makeText(PostActivity.this, "Posted Successfully", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if the data is not added or it is cancelled then
                // we are displaying a failure toast message.
                Toast.makeText(PostActivity.this, "Post Unsuccessful " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
    ***************************************************************
    Drawer Menu
     **************************************************************
     */
    public void ClickMenu(View view){
        //open drawer
        Navigation.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        Navigation.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //Redirect activity to Home
        Navigation.redirectActivity(this, MainActivity.class);
    }

    public void ClickPost(View view){
        //Recreate activity
        recreate();
    }

    public void ClickMessage(View view){
        //Redirect activity to Messages
        Navigation.redirectActivity(this, ChatsActivity.class);
    }

    public void ClickProfile(View view){
        //Redirect activity to Profile
        Navigation.redirectActivity(this, ProfilePage.class);
    }

    public void ClickFriends(View view){
        //Redirect activity to Friends
        com.example.radiermeet2.Navigation.redirectActivity(this, FriendsActivity.class);
    }

    public void ClickLogout(View view){
        //close app
        Navigation.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        Navigation.closeDrawer(drawerLayout);
    }

}