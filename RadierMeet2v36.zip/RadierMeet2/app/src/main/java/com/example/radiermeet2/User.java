package com.example.radiermeet2;

public class User {

    public String firstName, lastName, email, major, classification, gender, age, hobbies, userID;

    public User() {
    }

    public User(String firstName, String lastName, String email, String major, String classification, String gender, String age, String hobbies){
        this.firstName=firstName;
        this.lastName=lastName;
        this.email=email;
        this.major=major;
        this.classification=classification;
        this.gender=gender;
        this.age=age;
        this.hobbies=hobbies;

    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getMajor() { return major; }

    public String getClassification() {
        return classification;
    }

    public String getGender() {
        return gender;
    }

    public String getAge() {
        return age;
    }

    public String getHobbies() {
        return hobbies;
    }

    public String getuserID() {
        return userID;
    }
}
