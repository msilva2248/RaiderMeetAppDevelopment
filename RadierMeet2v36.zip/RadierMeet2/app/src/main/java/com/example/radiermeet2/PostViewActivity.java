package com.example.radiermeet2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class PostViewActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;

    RecyclerView recyclerView;
    private com.example.radiermeet2.PostAdapter.OnItemListener onItemListener;
    DatabaseReference database, userDatabase;
    com.example.radiermeet2.PostAdapter mainAdapter;
    ArrayList<Post> PostList;
    ArrayList<com.example.radiermeet2.User> UserList, users;
    FirebaseUser cUser;
    String uId;
    String title;
    String message;
    ArrayList<String> hobbies = new ArrayList<String>();
    String mTitle;
    String mMessage;
    com.example.radiermeet2.User tmpUsr;
    StorageReference storageReference;
    StorageReference photoReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_view);

        drawerLayout = findViewById(R.id.drawer_layout);

        // Assign variable
        recyclerView = findViewById(R.id.PostRecyclerView);
        database = FirebaseDatabase.getInstance().getReference("Post");
        userDatabase = FirebaseDatabase.getInstance().getReference("Users");
        cUser = FirebaseAuth.getInstance().getCurrentUser();
        uId = cUser.getUid();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        storageReference = FirebaseStorage.getInstance().getReference();
        photoReference = storageReference.child("users/" + uId + "/profile.jpg");

        PostList = new ArrayList<>();
        UserList = new ArrayList<>();
        users = new ArrayList<>();

        onItemListener = new com.example.radiermeet2.PostAdapter.OnItemListener() {
            @Override
            public void onItemClick(View v, int position) {
                Intent intent = new Intent(getApplicationContext(), UserProfileActivity.class);
                intent.putExtra("firstName", UserList.get(position).getFirstName());
                intent.putExtra("lastName", UserList.get(position).getLastName());
                intent.putExtra("email", UserList.get(position).getEmail());
                intent.putExtra("major", UserList.get(position).getMajor());
                intent.putExtra("classification", UserList.get(position).getClassification());
                intent.putExtra("gender", UserList.get(position).getGender());
                intent.putExtra("age", UserList.get(position).getAge());
                intent.putExtra("hobbies", UserList.get(position).getHobbies());
                intent.putExtra("userID", UserList.get(position).getuserID());
                startActivity(intent);
            }
        };

        mainAdapter = new com.example.radiermeet2.PostAdapter(this, PostList, onItemListener);
        recyclerView.setAdapter(mainAdapter);

        userDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    com.example.radiermeet2.User user = dataSnapshot.getValue(com.example.radiermeet2.User.class);

                    if (user.getFirstName() != null) {
                        users.add(user);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                title = snapshot.child(uId).child("title").getValue(String.class);
                message = snapshot.child(uId).child("message").getValue(String.class);

                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    Post post = dataSnapshot.getValue(Post.class);

                    for (com.example.radiermeet2.User usr : users) {
                        if(usr.userID != null){
                            if(usr.userID.equals(dataSnapshot.getKey())){
                                tmpUsr = new com.example.radiermeet2.User(usr.firstName, usr.lastName, usr.email, usr.major,
                                        usr.classification, usr.gender, usr.age, usr.hobbies);
                                tmpUsr.userID = usr.userID;
                            }
                        }
                    }

                    mTitle = post.getTitle();
//                    if(mTitle != null && mTitle.equals(title))
//                        continue;
                    mMessage = post.getMessage();

                    if( mTitle != null && mMessage != null ) {
                        PostList.add(post);
                        UserList.add(tmpUsr);
                    }
                }

                mainAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void goToPost(View view) {
        com.example.radiermeet2.Navigation.redirectActivity(PostViewActivity.this, com.example.radiermeet2.PostActivity.class);
    }

    /*
    ***************************************************************
    Drawer Menu
     **************************************************************
     */
    public void ClickMenu(View view){
        //open drawer
        com.example.radiermeet2.Navigation.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        com.example.radiermeet2.Navigation.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //Redirect activity to Home
        com.example.radiermeet2.Navigation.redirectActivity(this, MainActivity.class);
    }

    public void ClickPost(View view){
        //Recreate activity
        recreate();
    }

    public void ClickFriends(View view){
        //Redirect activity to Friends
        com.example.radiermeet2.Navigation.redirectActivity(this, FriendsActivity.class);
    }

    public void ClickMessage(View view){
        //Redirect activity to Messages
        com.example.radiermeet2.Navigation.redirectActivity(this, com.example.radiermeet2.ChatsActivity.class);
    }

    public void ClickProfile(View view){
        //Redirect activity to Profile
        com.example.radiermeet2.Navigation.redirectActivity(this, ProfilePage.class);
    }

    public void ClickLogout(View view){
        //close app
        com.example.radiermeet2.Navigation.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        com.example.radiermeet2.Navigation.closeDrawer(drawerLayout);
    }

}