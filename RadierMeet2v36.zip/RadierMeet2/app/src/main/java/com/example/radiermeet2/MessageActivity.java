package com.example.radiermeet2;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

// Junwoo Jang
public class MessageActivity extends AppCompatActivity {
  /*
     Activity that shows the actual chatting with a user.
 */


    private static final String CHATS_PATH = "Chats";
    // Chats path in database, same as in ChatsActivity
    public static final String EXTRA_CONTACT_UID = "contactUID";
    // A string Used to pass the User ID of the contact we're chatting with to this activity.

    private DrawerLayout drawerLayout; //Drawer Layout

    private final DatabaseReference dbChats = FirebaseDatabase.getInstance().getReference(CHATS_PATH);
    // Reference to database in chats, again
    private String userUID;
    private String contactUID;
    private ArrayList<Message> messagesList;
    // List of Message class instances that represent our chat with the contact (Message.java)

    LinearLayout messagesLayout;
    // Reference to the part of the layout where we add the message views.
    ImageView sendButton;
    // sendButton reference
    EditText messageArea;
    // where we type our message:messageArea reference
    ScrollView scrollView;
    // Reference to the scroll view holding our messages to allow scrolling.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        Bundle extras = getIntent().getExtras();
        if (extras == null || !extras.containsKey(EXTRA_CONTACT_UID)) {
            // Check if we got extras, and check if they contain a contactUID, otherwise exit
            // Extras containing contact UID are passed from two places. 1) (UserProfileActivity:87) 2) (ChatsActivity:214)

            Toast.makeText(this, "Missing contactUID, exiting.", Toast.LENGTH_SHORT).show();
            finish(); // stop creating the activity and exit
            return; // return from onCreate
        }


        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            // (Just to catch bugs) Check if our user is signed in, otherwise exit. This shouldn't happen.
            Toast.makeText(this, "User not signed in, exiting.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        contactUID = getIntent().getExtras().getString(EXTRA_CONTACT_UID);
        // get contact UID from extras.
        userUID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        // get our user UID. (Only when you log in)


        if (userUID.equals(contactUID)) {
            Toast.makeText(this, "You can't message yourself, exiting.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        drawerLayout = findViewById(R.id.drawer_layout);
        messagesLayout = (LinearLayout) findViewById(R.id.messagesLayout);
        sendButton = (ImageView) findViewById(R.id.sendButton);
        messageArea = (EditText) findViewById(R.id.messageArea);
        scrollView = (ScrollView) findViewById(R.id.scrollView);
// Find our layouts


        DatabaseReference chatRef1 = dbChats.child(userUID + "_" + contactUID);
        DatabaseReference chatRef2 = dbChats.child(contactUID + "_" + userUID);
        // Get two references inside the chats database(1:user_contact, 2:contact_user)
        // These are used To store the messages in the database when a new message is sent.

        chatRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                // Get the already present messages from the database.

                // The ValueEventListener will run once we create the activity, and every time a new
                // message is added to the database.


                GenericTypeIndicator<ArrayList<Message>> t = new GenericTypeIndicator<ArrayList<Message>>() {
                };  // Creates a Type to tell firebase how to get the messages into ArrayList<Message> From firebase documentation

                messagesList = snapshot.getValue(t); // Get the messages
                if (messagesList != null) {
                    // If we have messages (sometimes not: code below for the case)

                    showMessages(messagesList);// show them on the screen.

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // Handle the send Button. When clicked, onClick will be triggered

                Message message = new Message(userUID, contactUID, messageArea.getText().toString(), System.currentTimeMillis());
                // Create a message instance (Message.java)
                // userUID as sender, contactUID as receiver, etc…

                if (messagesList == null) {
                    //if we don't have previous messages and we're sending the first one

                    messagesList = new ArrayList<>(); // create an empty array in that case
                }
                messagesList.add(message); // add the new message to our messagesList.
                messageArea.setText(""); // // clear messageArea to enable sending of the next message

                chatRef1.setValue(messagesList);
                chatRef2.setValue(messagesList);
                // add the updated messageList to those two database references
            }
        });
    }

    private void showMessages(ArrayList<Message> messages) {
        // This function is called whenever we first open the activity and get the messages
        // and every time a new message is added to our database (sent by the user or by the contact)
        // This will actually create a view for each message and show it on the screen.


        messagesLayout.removeAllViews();  // Remove old messages


        for (Message msg : messages) {
            // Add the updated message views
            // For every message in our messageList

            View msg_layout = getLayoutInflater().inflate(R.layout.single_message_layout, messagesLayout, false);
            // Create the basic view.

            TextView msg_layout_contents = msg_layout.findViewById(R.id.sml_content);
            // Find where we should add the contents

            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) msg_layout_contents.getLayoutParams();
            // get layout parameters to change the side the message is showed on
            // the user (on the right) or the contact (on the left)



            params.setMargins(10, 15, 10, 15); //Space between each messages

            if (msg.senderUID.equals(userUID)) {  // If we sent the message
                params.gravity = Gravity.RIGHT;// Show it on the right
                msg_layout_contents.setBackgroundResource(R.drawable.rounded_corner1);
            } else { // If the contact sent the message
                params.gravity = Gravity.LEFT;

                msg_layout_contents.setBackgroundResource(R.drawable.rounded_corner2);
            }

            msg_layout_contents.setLayoutParams(params);
            // Set our updated layout parameters to the message view

            msg_layout_contents.setText(msg.contents);
            // set the contents of the message inside the view
            messagesLayout.addView(msg_layout);
            // add the view to the messagesLayout (on the screen)
        }


        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(View.FOCUS_DOWN);
            }
        }); // Scroll to the end to show the last messages
    }

    /*
    ***************************************************************
    Drawer Menu
     **************************************************************
     */
    public void ClickMenu(View view) {

        Navigation.openDrawer(drawerLayout); //open drawer
    }

    public void ClickLogo(View view) {

        Navigation.closeDrawer(drawerLayout); //close drawer
    }

    public void ClickHome(View view) {

        Navigation.redirectActivity(this, MainActivity.class);
        //Redirect activity to Home
    }

    public void ClickPost(View view) {

        Navigation.redirectActivity(this, PostViewActivity.class);
        //Redirect activity to Post

    }

    public void ClickMessage(View view) {

        Navigation.redirectActivity(this, ChatsActivity.class);
        //Redirect activity to chats
    }

    public void ClickProfile(View view) {

        Navigation.redirectActivity(this, ProfilePage.class);
        //Redirect activity to Profile
    }

    public void ClickLogout(View view) {

        Navigation.logout(this);  //close app
    }

    @Override
    protected void onPause() {
        super.onPause();

        Navigation.closeDrawer(drawerLayout); //close drawer
    }

}